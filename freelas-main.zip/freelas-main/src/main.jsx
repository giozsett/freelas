import React from 'react';
import ReactDOM from 'react-dom/client';
import Aplicacao from './Aplicacao.jsx';
import './index.css';
import { ProvedorTema } from './contexto/ContextoTema.jsx';
import { ProvedorAutenticacao } from './contexto/ContextoAutenticacao.jsx';
import { ProvedorPermissao } from './contexto/ContextoPermissao.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ProvedorAutenticacao>
      <ProvedorPermissao>
        <ProvedorTema>
          <Aplicacao />
        </ProvedorTema>
      </ProvedorPermissao>
    </ProvedorAutenticacao>
  </React.StrictMode>,
);
