import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Moon, Sun, Bell, MessageSquare, UserCircle } from 'lucide-react';
import { useTema } from '../contexto/ContextoTema';
import { useAutenticacao } from '../contexto/ContextoAutenticacao';
import { usePermissao } from '../contexto/ContextoPermissao';

export default function BarraNavegacao() {
  const { tema, alternarTema } = useTema();
  const { usuario, sair } = useAutenticacao();
  const { permissao, alternarPermissao } = usePermissao();
  const [menuAberto, setMenuAberto] = useState(false);
  const referenciaMenu = useRef(null);
  const navigate = useNavigate();

  // Notificações simuladas para demonstração
  const [temNovasMensagens] = useState(true);
  const [temNovasCandidaturas] = useState(true);

  useEffect(() => {
    function lidarCliqueFora(event) {
      if (referenciaMenu.current && !referenciaMenu.current.contains(event.target)) {
        setMenuAberto(false);
      }
    }
    document.addEventListener("mousedown", lidarCliqueFora);
    return () => document.removeEventListener("mousedown", lidarCliqueFora);
  }, []);

  const realizarLogout = () => {
    sair();
    setMenuAberto(false);
    navigate('/entrar');
  };

  return (
    <nav className="navbar">
      <Link to="/" className="brand">FREELAS</Link>

      <div className="navbar-nav">
        {usuario ? (
          <>

            <Link to="/create-ad" className="btn" style={{ padding: '0.4rem 0.8rem', fontSize: '0.85rem', borderRadius: '20px' }}>Postar Anúncio</Link>

            {/* Botão de alternância */}
            <div className="switch-container">
              <label className="switch">
                <input type="checkbox" checked={permissao === 'contractor'} onChange={alternarPermissao} />
                <span className="slider-switch">
                  <span className="switch-text freela">Freelancer</span>
                  <span className="switch-text contra">Contratante</span>
                </span>
              </label>
            </div>





            <button
              onClick={alternarTema}
              title="Alternar Tema"
              style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-color)', display: 'flex', marginRight: 'auto' }}
            >
              {tema === 'light' ? <Moon size={22} /> : <Sun size={22} />}
            </button>

            <Link to="/chat" title="Mensagens" aria-label="Mensagens" style={{ color: 'var(--text-color)', display: 'flex', alignItems: 'center', position: 'relative' }}>
              <MessageSquare size={24} />
              {temNovasMensagens && <div className="notification-dot"></div>}
            </Link>

            {/* Perfil Dropdown */}
            <div className="dropdown" ref={referenciaMenu}>
              <div
                style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', color: 'var(--text-color)', position: 'relative' }}
                onClick={() => setMenuAberto(!menuAberto)}
                title="Opções de Perfil"
              >
                <UserCircle size={28} />
                {temNovasCandidaturas && <div className="notification-dot"></div>}
              </div>
              <div className="dropdown-content" style={{ display: menuAberto ? 'block' : 'none' }}>
                <Link to="/profile" className="dropdown-item" onClick={() => setMenuAberto(false)}>Meu Perfil</Link>
                <Link to="/profile/edit" className="dropdown-item" onClick={() => setMenuAberto(false)}>Editar Perfil</Link>
                <Link to="/my-ads" className="dropdown-item" onClick={() => setMenuAberto(false)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  Meus Anúncios
                  {temNovasCandidaturas && permissao === 'contractor' && <div className="notification-dot" style={{ position: 'static' }}></div>}
                </Link>
                <Link to="/my-applications" className="dropdown-item" onClick={() => setMenuAberto(false)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  Minhas Candidaturas
                  {temNovasCandidaturas && permissao === 'freelancer' && <div className="notification-dot" style={{ position: 'static' }}></div>}
                </Link>
                <Link to="/planos" className="dropdown-item" onClick={() => setMenuAberto(false)}>Planos e Assinaturas</Link>
                <Link to="/my-payments" className="dropdown-item" onClick={() => setMenuAberto(false)}>Meus Pagamentos</Link>
                <button
                  onClick={realizarLogout}
                  className="dropdown-item"
                  style={{ width: '100%', textAlign: 'left', background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: '1rem', color: 'var(--holo-salmon)' }}
                >
                  Sair
                </button>
              </div>
            </div>
          </>
        ) : (
          <>
            <Link to="/entrar" style={{ fontWeight: '500' }}>Entrar</Link>
            <button
              onClick={alternarTema}
              title="Alternar Tema"
              style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-color)', display: 'flex' }}
            >
              {tema === 'light' ? <Moon size={22} /> : <Sun size={22} />}
            </button>
          </>
        )}
      </div>
    </nav>
  );
}
