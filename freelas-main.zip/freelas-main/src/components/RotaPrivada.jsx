import { Navigate } from 'react-router-dom';
import { useAutenticacao } from '../contexto/ContextoAutenticacao';

export default function RotaPrivada({ children }) {
  const { usuario, carregando } = useAutenticacao();

  if (carregando) {
    return <div style={{ textAlign: 'center', marginTop: '5rem' }}>Carregando...</div>;
  }

  if (!usuario) {
    return <Navigate to="/entrar" replace />;
  }

  return children;
}
