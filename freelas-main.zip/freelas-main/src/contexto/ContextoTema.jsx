import { createContext, useState, useEffect, useContext } from 'react';

const ContextoTema = createContext();

export const ProvedorTema = ({ children }) => {
  const [tema, setTema] = useState('light');

  useEffect(() => {
    const temaSalvo = localStorage.getItem('tema');
    if (temaSalvo) {
      setTema(temaSalvo);
      document.documentElement.setAttribute('data-tema', temaSalvo);
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTema('dark');
      document.documentElement.setAttribute('data-tema', 'dark');
    }
  }, []);

  const alternarTema = () => {
    const novoTema = tema === 'light' ? 'dark' : 'light';
    setTema(novoTema);
    localStorage.setItem('tema', novoTema);
    document.documentElement.setAttribute('data-tema', novoTema);
  };

  return (
    <ContextoTema.Provider value={{ tema, alternarTema }}>
      {children}
    </ContextoTema.Provider>
  );
};

export const useTema = () => useContext(ContextoTema);
