import { createContext, useState, useEffect, useContext } from 'react';

const ContextoAutenticacao = createContext();

export const ProvedorAutenticacao = ({ children }) => {
  const [usuario, setUsuario] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token') || null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    if (token) {
      // Valida o token ou recupera os dados do usuário armazenados por enquanto
      // Em uma aplicação real, buscaríamos o perfil do usuário em /api/auth/user/
      fetch('http://localhost:8000/api/auth/user/', {
        headers: {
          'Authorization': `Token ${token}`
        }
      })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Token is invalid');
      })
      .then(data => {
        setUsuario(data);
      })
      .catch(err => {
        console.error(err);
        sair();
      })
      .finally(() => setCarregando(false));
    } else {
      setCarregando(false);
    }
  }, [token]);

  const entrar = (dadosUsuario, tokenAutenticacao) => {
    setUsuario(dadosUsuario);
    setToken(tokenAutenticacao);
    localStorage.setItem('token', tokenAutenticacao);
  };

  const sair = () => {
    setUsuario(null);
    setToken(null);
    localStorage.removeItem('token');
  };

  return (
    <ContextoAutenticacao.Provider value={{ usuario, token, entrar, sair, carregando }}>
      {children}
    </ContextoAutenticacao.Provider>
  );
};

export const useAutenticacao = () => useContext(ContextoAutenticacao);
