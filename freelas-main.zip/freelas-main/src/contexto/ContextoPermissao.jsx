import { createContext, useState, useEffect, useContext } from 'react';

const ContextoPermissao = createContext();

export const ProvedorPermissao = ({ children }) => {
  // 'freelancer' ou 'contractor'
  const [permissao, setPermissao] = useState(localStorage.getItem('platform_role') || 'freelancer');

  useEffect(() => {
    document.documentElement.setAttribute('data-permissao', permissao);
  }, [permissao]);

  const alternarPermissao = () => {
    const novaPermissao = permissao === 'freelancer' ? 'contractor' : 'freelancer';
    setPermissao(novaPermissao);
    localStorage.setItem('platform_role', novaPermissao);
    document.documentElement.setAttribute('data-permissao', novaPermissao);
  };

  return (
    <ContextoPermissao.Provider value={{ permissao, alternarPermissao }}>
      {children}
    </ContextoPermissao.Provider>
  );
};

export const usePermissao = () => useContext(ContextoPermissao);
